import { Router } from 'express';
import { getTasks, getTaskById, createTask, updateTask, deleteTask } from '../controllers/taskController.js';
import { validateTask } from '../middleware/validate.js';
const router = Router();
router.route('/').get(getTasks).post(validateTask, createTask);
router.route('/:id').get(getTaskById).put(validateTask, updateTask).delete(deleteTask);
export default router;