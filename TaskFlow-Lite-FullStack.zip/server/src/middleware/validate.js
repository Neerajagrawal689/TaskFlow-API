import { z } from 'zod';
const taskSchema = z.object({ text: z.string().min(3, 'Text must be at least 3 chars').max(255), completed: z.boolean().optional() });
export const validateTask = (req, res, next) => {
  try { taskSchema.parse(req.body); next(); } catch (err) { return res.status(400).json({ error: err.errors[0].message }); }
};